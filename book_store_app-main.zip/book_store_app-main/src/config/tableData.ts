export const labels = [
    {
        value: "Final Article",
        label: "Bug",
    },
    {
        value: "feature",
        label: "Feature",
    },
    {
        value: "documentation",
        label: "Documentation",
    },
]

export const orderStatuses = [
    {
        value: "delivered",
        label: "Delivered",
    },
    {
        value: "onWay",
        label: "On way",
    },
    {
        value: "canceled",
        label: "Canceled",
    },
]
