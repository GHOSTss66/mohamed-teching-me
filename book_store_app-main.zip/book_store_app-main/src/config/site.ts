import { Icons } from "@/components/Icons"

export const navLinks = [
    {
        name: "Home",
        url: "/",
    },
    {
        name: "Shop",
        url: "/shop",
    },
    {
        name: "About",
        url: "/about",
    },
    {
        name: "Contact us",
        url: "/contact-us",
    },
]

export const supportLinks = [
    {
        name: "Getting started",
        url: "/getting-started",
    },
    {
        name: "Chat Our support",
        url: "/chat-support",
    },
    {
        name: "Help center",
        url: "/help",
    },
    {
        name: "Report a bug",
        url: "/report",
    },
]

export const books = [
    {
        id: 1,
        title: "Who Can You Trust?",
        author: "Rachel Botsman",
        cover: "/Book-5.webp",
        inventory: 10,
        categories: "ui/ux design",
        rating: 4,
        price: 380,
    },
    {
        id: 2,
        title: "The Good Guy",
        author: "Mark Maclalister",
        cover: "/Book-2.webp",
        inventory: 22,
        categories: "ui/ux design",
        rating: 2,
        price: 123,
    },
    {
        id: 3,
        title: "Beautiful Day",
        author: "Kate Anthony",
        cover: "/Book-3.webp",
        inventory: 5,
        categories: "ui/ux design",
        rating: 1,
        price: 111,
    },
    {
        id: 4,
        title: "Scavenger",
        author: "Darren Simpson",
        cover: "/Book-4.webp",
        inventory: 2,
        categories: "ui/ux design",
        rating: 5,
        price: 334,
    },
    {
        id: 5,
        title: "The Great Symphony",
        author: "Nancy Brown",
        cover: "/Book-1.webp",
        inventory: 0,
        categories: "ui/ux design",
        rating: 5,
        price: 10,
    },
    {
        id: 6,
        title: "Ford Boyard Challenge",
        author: "Ford Boyard",
        cover: "/Book-7.webp",
        inventory: 50,
        categories: "ui/ux design",
        rating: 2,
        price: 11,
    },
    {
        id: 7,
        title: "Lightfall",
        author: "MOhammed Raad",
        cover: "/Book-6.webp",
        inventory: 100,
        categories: "ui/ux design",
        rating: 1,
        price: 34,
    },
    {
        id: 8,
        title: "Night Of The Walkers",
        author: "Maurice Broaddus",
        cover: "/Book-8.webp",
        inventory: 98,
        categories: "ui/ux design",
        rating: 4,
        price: 99,
    },
    {
        id: 9,
        title: "Alone",
        author: "Maurice Madremon",
        cover: "/Book-9.jpg",
        inventory: 1,
        categories: "ui/ux design",
        rating: 3,
        price: 89,
    },
]

export const orders = [
    {
        id: 1,
        title: "Who Can You Trust?",
        author: "Rachel Botsman",
        cover: "/Book-5.webp",

        categories: "ui/ux design",
        rating: 4,
        price: 380,
        customerName: "a",
        customerAvatar: "/person-1.webp",
        status: "onWay",
    },
    {
        id: 2,
        title: "The Good Guy",
        author: "Mark Maclalister",
        cover: "/Book-2.webp",

        categories: "ui/ux design",
        rating: 2,
        price: 123,
        customerName: "b",
        customerAvatar: "/person-2.webp",
        status: "delivered",
    },
    {
        id: 3,
        title: "Beautiful Day",
        author: "Kate Anthony",
        cover: "/Book-3.webp",
        categories: "ui/ux design",
        rating: 1,
        price: 111,
        customerName: "c",
        customerAvatar: "/person-3.webp",
        status: "delivered",
    },
    {
        id: 4,
        title: "Scavenger",
        author: "Darren Simpson",
        cover: "/Book-4.webp",
        categories: "ui/ux design",
        rating: 5,
        price: 334,
        customerName: "d",
        customerAvatar: "/person-4.webp",
        status: "canceled",
    },
    {
        id: 5,
        title: "The Great Symphony",
        author: "Nancy Brown",
        cover: "/Book-1.webp",
        categories: "ui/ux design",
        rating: 5,
        price: 10,
        customerName: "e",
        customerAvatar: "/person-5.webp",
        status: "onWay",
    },
    {
        id: 6,
        title: "Ford Boyard Challenge",
        author: "Ford Boyard",
        cover: "/Book-7.webp",

        categories: "ui/ux design",
        rating: 2,
        price: 11,
        customerName: "f",
        customerAvatar: "/person-1.webp",
        status: "canceled",
    },
    {
        id: 7,
        title: "Lightfall",
        author: "MOhammed Raad",
        cover: "/Book-6.webp",

        categories: "ui/ux design",
        rating: 1,
        price: 34,
        customerName: "j",
        customerAvatar: "/person-5.webp",
        status: "delivered",
    },
    {
        id: 8,
        title: "Night Of The Walkers",
        author: "Maurice Broaddus",
        cover: "/Book-8.webp",

        categories: "ui/ux design",
        rating: 4,
        price: 99,
        customerName: "h",
        customerAvatar: "/person-4.webp",
        status: "canceled",
    },
    {
        id: 9,
        title: "Alone",
        author: "Maurice Madremon",
        cover: "/Book-9.jpg",
        categories: "ui/ux design",
        rating: 3,
        price: 89,
        customerName: "i",
        customerAvatar: "/person-2.webp",
        status: "delivered",
    },
]

export const socialMediaLinks = [
    {
        name: "Facebook",
        url: "https://www.facebook.com",
        Icon: Icons.Facebook,
    },
    {
        name: "Twitter",
        url: "https://www.twitter.com",
        Icon: Icons.Twitter,
    },
    {
        name: "Instagram",
        url: "https://www.instagram.com",
        Icon: Icons.Instagram,
    },
    {
        name: "Youtube",
        url: "https://www.youtube.com",
        Icon: Icons.Youtube,
    },
]

export const footerLinks = [
    {
        groupName: "QuickLinks",
        links: navLinks,
    },
    {
        groupName: "Social Media",
        links: socialMediaLinks.map(({ name, url }) => ({ name, url })),
    },
    {
        groupName: "Support",
        links: supportLinks,
    },
]

export type Testimonial = {
    name: string
    jobTitle: string
    avatar: string
    comment: string
}

export const testimonials: Testimonial[] = [
    {
        name: "JOHN ANDERSON",
        jobTitle: "University Student",
        avatar: "/person-1.webp",
        comment:
            "The university student experience has been greatly enriched by the presence of the bookstore library. Its abundant resources, serene environment, and expert guidance have significantly contributed to my academic success.",
    },
    {
        name: "MICHAEL SMITH",
        jobTitle: "Graduate Student",
        avatar: "/person-2.webp",
        comment:
            "As a dedicated graduate student, I've found the library to be a pivotal resource. Its cutting-edge tech resources, workshops, and a supportive atmosphere have propelled my research and career ambitions forward.",
    },

    {
        name: "ROBERT JOHNSON",
        jobTitle: "Book Lover",
        avatar: "/person-3.webp",
        comment:
            "For a true book lover, the library is a sanctuary of discovery. Within its shelves, I've embarked on captivating journeys through history and literature, thanks to its remarkable collection.",
    },
    {
        name: "DAVID MILLER",
        jobTitle: "Educator",
        avatar: "/person-4.webp",
        comment:
            "Educators like me rely on the library's extensive educational resources to create enriching learning experiences. The knowledgeable staff provide invaluable guidance, making it an essential asset for educators.",
    },
    {
        name: "STEVEN WILSON",
        jobTitle: "Ph.D. Candidate",
        avatar: "/person-5.webp",
        comment:
            "For a Ph.D. candidate, access to comprehensive research materials is paramount. The library has played a pivotal role in my academic journey, offering the resources I need to excel in my field.",
    },
    {
        name: "MICHAEL JONES",
        jobTitle: "Business Professional",
        avatar: "/person-6.webp",
        comment:
            "In the world of business, research is paramount, and the library simplifies this task. Its extensive resources and the assistance of its knowledgeable staff have proven invaluable to me as a business professional.",
    },
]

export const values = [
    {
        title: "Curiosity Unleashed",
        description:
            "Embrace endless exploration. We celebrate curiosity's role in unearthing new worlds and broadening horizons.",
        Icon: Icons.Book,
        color: "#FFB000",
    },
    {
        title: "Empathy in Stories",
        description:
            "Experience lives beyond your own. Through narratives, we cultivate empathy and connect diverse perspectives.",
        Icon: Icons.Lovely,
        color: "#4CAF50",
    },
    {
        title: "Curation Excellence",
        description:
            "Meticulously selected. Our collection reflects quality, diversity, and the art of meaningful curation.",
        Icon: Icons.Books,
        color: "#2979FF",
    },
    {
        title: "Community of Readers",
        description:
            "More than a store. We're a haven for like-minded readers, fostering connections, discussions, and shared passion.",
        Icon: Icons.People,
        color: "#E91E63",
    },
]

export const contactLinks = [
    {
        title: "Sales",
        description:
            "Explore new literary worlds with us. Reach out for inquiries, book recommendations, and purchases that kindle your imagination.",
        Icon: Icons.HandPills,
        color: "#4ADE80",
        linkName: "Contact sales",
        url: "contact-us",
    },
    {
        title: "Help & Support",
        description:
            "We're here to assist you. Contact us for any support you need, from order inquiries to navigating our offerings.",
        Icon: Icons.Headset,
        color: "#7B61FF",
        linkName: "Get support",
        url: "contact-us",
    },
    {
        title: "Media & Press",
        description:
            "Journalists, reviewers, and partners, let's connect. Reach out to explore collaboration opportunities and discover our latest narratives.",
        Icon: Icons.Airplay,
        color: "#0B63E5",
        linkName: "Get press kit",
        url: "contact-us",
    },
]
export type BooksType = typeof books
