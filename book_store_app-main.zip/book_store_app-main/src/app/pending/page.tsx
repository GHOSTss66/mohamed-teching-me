import { FC } from "react"

interface pageProps {}

const page: FC<pageProps> = ({}) => {
    return <div>pending</div>
}

export default page
