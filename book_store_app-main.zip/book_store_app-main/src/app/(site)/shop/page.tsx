import { FC } from "react"

interface pageProps {}

const page: FC<pageProps> = ({}) => {
    return <div>page</div>
}

export default page
