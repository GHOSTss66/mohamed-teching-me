import { FC } from "react"

import { DataTable } from "@/components/ui/DataTable"

// import { columns } from "@/components/MyBooksColumns"

interface pageProps {}

const page: FC<pageProps> = ({}) => {
    return (
        <div>
            {/* <DataTable columns={columns} data={[]} /> */}
            hello world
        </div>
    )
}

export default page
